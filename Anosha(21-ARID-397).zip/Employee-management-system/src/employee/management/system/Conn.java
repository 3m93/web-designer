
package employee.management.system;

import java.sql.*;

public class Conn {
    Connection c;
    Statement a;
    public Conn()
    {
        try{
            
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","Anosha&123");
            a=c.createStatement();
            
            
        }        catch(Exception e){
            System.out.println(e);
        }
    }
    
    
}
