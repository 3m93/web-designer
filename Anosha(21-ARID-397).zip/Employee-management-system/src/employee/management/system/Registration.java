package employee.management.system;
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.text.NumberFormat;
import java.util.Random;
import java.awt.event.*;


public class Registration extends JFrame implements ActionListener{
    JTextField nametextfield, addresstextfield,  phonetextfield, emailtextfield;
    JButton button;
    Registration()
    {
        setLayout(null);
        Random ran=new Random();
       long random=(Math.abs((ran.nextLong()%9000L)+1000L));
        JLabel formno=new JLabel("Application Form No."+random);
        formno.setBounds(140,20,600,40);
        add(formno);
        
        JLabel personalDetails=new JLabel("Personal Details");
        personalDetails.setBounds(280,70,350,30);
        add(personalDetails);
        
        JLabel name=new JLabel("Name");
        name.setBounds(90,130,350,30);
        add(name);
         nametextfield=new JTextField();
        nametextfield.setFont(new Font("Raleway",Font.BOLD,14));
        nametextfield.setBounds(200,130,400,30);
        add(nametextfield);
                
        JLabel Address =new JLabel("Address");
        Address.setBounds(90,190,350,30);
        add(Address);
        addresstextfield=new JTextField(10);
        addresstextfield.setFont(new Font("Raleway",  Font.BOLD,14));
        addresstextfield.setBounds(200,190,400,30);
        add(addresstextfield);
        
        JLabel Phone=new JLabel("Phone");
        Phone.setBounds(90,250,350,30);
        add(Phone);
        phonetextfield=new JTextField();
        phonetextfield.setFont(new Font("Raleway",Font.BOLD,14));
        phonetextfield.setBounds(200,250,400,30);
        add(phonetextfield);
        
        JLabel Email=new JLabel("Email");
        Email.setBounds(90,310,350,30);
        add(Email);
       emailtextfield=new JFormattedTextField(NumberFormat.getNumberInstance());
        emailtextfield.setFont(new Font("Raleway",Font.BOLD,14));
        emailtextfield.setBounds(200,310,400,30);
        add(emailtextfield);
        
        JCheckBox agreement=new JCheckBox("Agreement");
        agreement.setBounds(90,370,350,30);
        add(agreement);
        
         button=new JButton("Submitt");
         button.setBounds(300,500,90,40);
         add(button);
        
        getContentPane().setBackground(Color.WHITE);
        setSize(750, 700);
        setLocation(400,15);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        String name=nametextfield.getText();
        String address=addresstextfield.getText();
        String phone=phonetextfield.getText();
        String email=emailtextfield.getText();
        
    }
 
    
    
    public static void main(String args[])
    {
        new Registration();
    }

   
}
