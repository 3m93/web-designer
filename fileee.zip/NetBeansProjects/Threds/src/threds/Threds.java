
package threds;

class MyThread1 extends Thread
{
    @Override
    public void run()
    {
        int i=0;
        while(i<100)
        {
            System.out.println("a");
            //System.out.println("Thread 1 is running");
            // System.out.println("i am happy");
            i++;
        }
    }
    
}
class MyThread2 extends Thread
{
    @Override
    public void run()
    {
        int i=0;
        while(i<100)
        {
            System.out.println("b");
           // System.out.println("Thread 2 is running");
           //  System.out.println("i am  not happy");
           i++;
        }
    }
    
}


public class Threds {   
    public static void main(String[] args) {
        MyThread1 t1=new MyThread1();
        MyThread2 t2=new MyThread2();
        t1.start();
         t2.start();
        
        
    }
    
}
