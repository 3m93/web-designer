package threds;

 
 class ThreadRun1 implements Runnable{
    @Override
    public void run()
    {
        int i=0;
        while(i<20)
        {
         System.out.println("i am happy");
        i++;
        }
    }
    
}

 class ThreadRun2 implements Runnable{
    @Override
    public void run()
    {int i=0;
        while(i<20)
         System.out.println("i am sad");
        i++;
    }
    
}
public class ThreadRunable
{
    public static void main(String[] args) {
    ThreadRun1 t1=new  ThreadRun1();
    Thread th1=new Thread((Runnable) t1);
    th1.start();
    ThreadRun2 t2=new  ThreadRun2();
     Thread th2=new Thread(t2);
     th2.start();
    }
}

