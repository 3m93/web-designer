/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author m
 */


package thread;


public class Client {
    public static void main(String[] args)
    {
        TaskClass task=new TaskClass();
        Thread thread=new Thread(task);
        thread.start();
        Thread2 task2=new Thread2();
        Thread thread1=new Thread(task2);
        thread1.start();
    }
    
    
}