
package thread;


public class TaskClass implements Runnable{
    
     


    @Override
    public void run() {
       
        
        for(int i=0;i<100;i++)
        {
            System.out.println("a");
        }
        
        
        // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
