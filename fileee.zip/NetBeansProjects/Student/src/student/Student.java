
package student;

import java.util.ArrayList;


public class Student {
    
    Student()
    {
        ArrayList<Student> students=new ArrayList<Student>();
        students.add(new Student())
    }

    public static void main(String[] args) {
       new Student();
    }
    
}
